<?php 
$products = array(
                  array("title" => "Bert", "image" => "be.jpeg", "text" => "Dit is het Bert product", "prijs" => 12.5),
                  array("title" => "Ernie", "image" => "ernie.png", "text" => "Dit is het Ernie product", "prijs" => 14.5),
                  array("title" => "Rick", "image" => "rickandmorty.jpg", "text" => "Dit is het Rick product", "prijs" => 11.5)
  );

?> 