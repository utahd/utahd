<!DOCTYPE html> 
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="styles/style.css">
    <link rel="stylesheet" type="text/css" href="styles/stylehome.css">
    <link rel="stylesheet" type="text/css" href="styles/stylemainlayout1.css">
  </head> 
  <body>
  <div id="mainLayout">
  <div id="menu">
    <h3><b>TEC<br>3D</b></h3>
    <ul>
      <li> <a href="#"> HOME</a> </li>
      <li> <a href="#">PROJECTEN</a> </li>
      <li> <a href="#">SHOP</a> </li>
      <li> <a href="#">PRODUCT</a> </li>
      <li> <a href="#">CONTACT</a> </li>
    </ul>
      </div>
  <div id="fotos">
    <div id="foto1">
      <img src="Foto's doc/C2448-MANS2.jpg">
      <img src="Foto's doc/C2448-MANS_5.jpg">
      <img src="Foto's doc/C2450-CYVM.jpg">
    </div>

    <div id="foto1">
      <img src="Foto's doc/WEEGBAK_ATELIER1.jpg">
      <img src="Foto's doc/WEEGBAK_ATELIER6.jpg">
      <img src="Foto's doc/WEEGBAK_ATELIER3.jpg">
    </div>
 
    <div id="foto1">
      <img src="Foto's doc/drw.jpg">
      <img src="Foto's doc/DRW2.jpg">
      <img src="Foto's doc/DRWCYVM.jpg">
    </div>
  </div>
    <div id="about">
       <h1>
        HALLO
      </h1>
    </div>
    <div id="contact">
       <h1>
        HALLO
      </h1>
    </div>
    <div id="footer">
      <h1>
        HALLO
      </h1>
    </div>
    </div>   
  </body>
</html>